# K-9 Sentry Kernel — Release Bundle
## Sprints CB-2 · CB-3 · AEG-7 · AEG-9

---

## What's in this archive

### k9-llm-router/
Complete LLM router service + Sentry Kernel contracts + ZK proving pipeline.

**Sprint CB-2 — Semantic Cache + Guardrails + Hybrid RAG**
- `src/semantic_cache.py`    — FAISS + Redis, cosine threshold 0.92, 1h TTL
- `src/guardrails.py`        — Prompt injection, toxicity, PII redaction
- `src/hybrid_rag.py`        — Dense (pgvector) + Sparse (BM25) + Cohere rerank
- `main.py`                  — Wired into request pipeline (lifespan init, route hooks)

**Sprint CB-3 — Text-to-SQL Query Engine**
- `src/text_to_sql.py`       — NL→SQL, SELECT-only safety, rate limiting, 10k row cap
- `main.py`                  — POST /query, GET /query/stats

**Sprint AEG-7 — SessionKeyWallet (Intent-Based DeFi with Risk Guardrails)**
- `contracts/src/SessionKeyWallet.sol`    — ERC-4337 wallet, 7 Genesis Risk Parameters:
    maxDrawdownBps=150, maxPoolShareBps=200, maxPositionUsd=$25k,
    slippageBlueChip=30bps, slippageAlt=75bps, maxGasUsd=$3, cooldown=60s
    Whitelisted: Uniswap V3, Aave V3, Curve, Balancer V2 (Base Mainnet)
- `contracts/script/DeployAEG7.s.sol`     — Foundry deploy → Base Sepolia
- `contracts/test/SessionKeyWallet.t.sol` — Full Foundry test suite (all 7 guardrails)

**Sprint AEG-9 — ZK Proof of Rationality (JEPA CB-5 → Noir → Barretenberg)**
- `contracts/aeg9_circuit/src/main.nr`    — 6-invariant Noir circuit (275 ACIR opcodes)
- `contracts/aeg9_circuit/Nargo.toml`     — Noir package config
- `contracts/aeg9_circuit/Prover.toml`    — Pre-validated witness (READY TO PROVE)
- `contracts/aeg9_circuit/target/proof_of_rationality.json`  — Compiled circuit (proving key)
- `contracts/aeg9_circuit/target/proof_of_rationality.gz`    — Solved witness
- `src/k9_proof_shim.py`                  — JEPA→Field→Noir→bb pipeline

### k9-integration/
Cognitive Bus (CB-1) — Lovable edge functions + cb.v1 schema.
- `shared-types/cb-schema.ts`    — cb.v1 envelope (Zod)
- `orbitron-bus/orbitron-bus.ts` — Edge function (validate → persist → forward)
- `orbitron-bus/agent-*.ts`      — GPT/Claude/Gemini/Local adapters
- `orbitron-bus/migration_cb_messages.sql` — Run in Supabase SQL editor first

---

## Immediate next steps after extraction

### 1. Extract into WSL2 home (NOT /mnt/f — avoid NTFS perf hit)
```bash
cd ~
tar -xzf k9-aeg9-complete.tar.gz
```

### 2. Verify critical files exist
```bash
ls ~/k9-llm-router/contracts/aeg9_circuit/src/main.nr   # circuit
ls ~/k9-llm-router/src/k9_proof_shim.py                  # shim
ls ~/k9-llm-router/contracts/aeg9_circuit/Prover.toml    # witness inputs
```

### 3. Run the proving pipeline (bb already built on your homelab)
```bash
cd ~/k9-llm-router/contracts/aeg9_circuit

# Compile circuit → proving key
nargo compile

# Generate witness (or use the pre-validated one already in target/)
python3 ../../src/k9_proof_shim.py
nargo execute

# Generate SNARK proof (the moment)
bb prove \
  -b target/proof_of_rationality.json \
  -w target/proof_of_rationality.gz \
  -o proof_of_rationality.proof

# Generate Solidity verifier
bb write_vk -b target/proof_of_rationality.json -o vk
bb contract  -k vk -o ../../contracts/src/ProofOfRationalityVerifier.sol
```

### 4. Push everything to GitHub
```bash
cd ~/k9-llm-router
git init  # if fresh clone
git remote add origin git@github.com:MartyFreakinBird/k9-llm-router.git
git add -A
git commit -m "feat(CB-2/CB-3/AEG-7/AEG-9): Sentry Kernel — semantic cache, guardrails, hybrid RAG, Text-to-SQL, SessionKeyWallet + ZK Proof of Rationality"
git push origin main
```

---

## Environment variables needed (add to ~/.bashrc or WSL2 .env)
```
K9_JEPA_ENDPOINT=http://localhost:8765/route
SESSION_WALLET_ADDRESS=<deployed SessionKeyWallet on Base Sepolia>
BASE_SEPOLIA_RPC=https://sepolia.base.org
CIRCUITS_DIR=~/k9-llm-router/contracts/aeg9_circuit
PROOFS_DIR=~/k9-llm-router/proofs
```

---

## AEG-9 Circuit Invariants (what the proof guarantees)
| # | Invariant | Check |
|---|-----------|-------|
| A | Drawdown  | predicted_drawdown_risk_bps <= 150 (1.5%) |
| B | Slippage integrity | min_amount_out == amount_in - (amount_in * impact_bps / 10000) |
| C | Alignment | alignment_score >= 80/100 (0.80 governance grade) |
| D | Blast radius | blast_radius_metric >= 75/100 (original blast_radius <= 0.25) |
| E | Wallet binding | proof bound to session_wallet address (anti-replay) |
| F | Feature vector | feature_vector_hash != 0 (model had real market data) |
